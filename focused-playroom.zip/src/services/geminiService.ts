import { GoogleGenAI, Type } from "@google/genai";

const SYSTEM_INSTRUCTION = `Actúa como un Agente Pedagógico Inteligente especializado en análisis de atención mediante eye-tracking y tutoría adaptativa durante la lectura digital. 
Tienes conocimiento experto en psicología cognitiva de la lectura, detección de distracción (mind-wandering) y estrategias pedagógicas de re-enfoque.

Objetivo:
Analizar datos de seguimiento ocular proporcionados por el sistema y generar intervenciones pedagógicas breves, personalizadas y no intrusivas que ayuden al estudiante a recuperar la atención y mejorar la comprensión lectora.

Contexto:
Recibirás datos en formato JSON provenientes de un sistema de análisis de atención basado en eye-tracking.

Las métricas pueden incluir:
- tipo_distraccion (interna, externa, ninguna)
- tema_lectura
- parrafo_actual
- duracion_fijacion
- regresiones
- tiempo_fuera_pantalla
- progreso_lineal

Definiciones importantes:
Distracción interna: El estudiante mira el texto pero su mente divaga.
Distracción externa: El estudiante aparta la mirada de la pantalla.
Alta fijación (>500ms): Puede indicar dificultad de comprensión.
Regresiones frecuentes: El estudiante vuelve a leer texto anterior.
Tiempo fuera de pantalla (>5s): Posible distracción externa.

Acciones:
1. Analiza las métricas recibidas.
2. Determina el estado cognitivo probable del estudiante.
3. Selecciona una estrategia pedagógica adecuada.
4. Genera una intervención breve (máximo 25 palabras).
5. Evita ser intrusivo o crítico.
6. Mantén un tono motivador y pedagógico.
7. Si el estudiante parece concentrado, no generes intervención innecesaria.
8. Prioriza preguntas cortas que estimulen la reflexión.

Salida:
Devuelve únicamente un objeto JSON con la siguiente estructura:
{
"estado_atencion": "concentrado | distraccion_interna | distraccion_externa",
"intervencion_tipo": "pregunta | recordatorio | explicacion | motivacion | ninguna",
"mensaje_estudiante": "mensaje breve dirigido al estudiante",
"accion_ui": "mostrar_notificacion | resaltar_texto | ninguna"
}`;

export interface EyeTrackingData {
  tipo_distraccion: "interna" | "externa" | "ninguna";
  tema_lectura: string;
  parrafo_actual: number;
  duracion_fijacion: number; // ms
  regresiones: number;
  tiempo_fuera_pantalla: number; // s
  progreso_lineal: number; // 0-100
  perfil?: string;
  puntuacion?: number;
}

export interface AIResponse {
  estado_atencion: "concentrado" | "distraccion_interna" | "distraccion_externa";
  intervencion_tipo: "pregunta" | "recordatorio" | "explicacion" | "motivacion" | "ninguna";
  mensaje_estudiante: string;
  accion_ui: "mostrar_notificacion" | "resaltar_texto" | "ninguna";
}

export async function analizarAtencion(data: EyeTrackingData): Promise<AIResponse> {
  const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  const model = "gemini-3.1-flash-lite-preview";

  const prompt = `
Analiza el siguiente estado de lectura y responde SOLO en JSON:

${JSON.stringify(data)}

Reglas:
- Máximo 20 palabras en mensaje
- No repetir mensajes
- No intervenir si está concentrado

Formato:
{
"estado_atencion": "concentrado | distraccion_interna | distraccion_externa",
"intervencion_tipo": "pregunta | recordatorio | explicacion | motivacion | ninguna",
"mensaje_estudiante": "mensaje breve dirigido al estudiante",
"accion_ui": "mostrar_notificacion | resaltar_texto | ninguna"
}
`;

  const response = await genAI.models.generateContent({
    model: model,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          estado_atencion: { type: Type.STRING },
          intervencion_tipo: { type: Type.STRING },
          mensaje_estudiante: { type: Type.STRING },
          accion_ui: { type: Type.STRING },
        },
        required: ["estado_atencion", "intervencion_tipo", "mensaje_estudiante", "accion_ui"],
      },
    },
  });

  try {
    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (e) {
    console.error("Error parsing AI response", e);
    return {
      estado_atencion: "concentrado",
      intervencion_tipo: "ninguna",
      mensaje_estudiante: "",
      accion_ui: "ninguna",
    };
  }
}
